package com.userprogram;

public class CustomExceptions extends Exception {
	
	     public String toString()
	     {
	          return ("Age is less than or equal 15 . please ReEnter the Age");
	     }
	}