package com.area;

import java.util.Scanner;

public class Main {

	double length;
	double width;
	double area;
	static float a;
	static float b;

	Main() {
		this.length=length;
		this.width=width;
	}
	
	public void method(double a,double b)
	{
		 area=a*b;
		 System.out.println(+area);
	}
	public static void main(String[] args) {
		
		 Scanner sc=new Scanner(System.in);
		 System.out.println("enter length");
		 a=sc.nextFloat();
		 System.out.println("enter width");
		 b=sc.nextFloat();
	Main obj=new Main();
		obj.method(a, b);
		 obj.method(b, a);
		 obj.method(25, 45);
		 obj.method(25.54, 45.25);
		 
	}

}
