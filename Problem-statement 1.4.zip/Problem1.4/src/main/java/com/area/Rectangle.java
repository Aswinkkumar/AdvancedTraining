package com.area;

public class Rectangle {
	double length=0;
	double width=0;
	
	

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		if (length>0.0 && length<20.0)
		{
		this.length = length;
		}
		else
		{
			System.out.println("error");
		}
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	} 
	
	
	 Rectangle() 
	
	{
		this.length=length;
		this.width=width;
	}
	
	public void perimeter()
	{
		double per=length+length+width+width;
		System.out.println(per);
	}
	
	public void arearect()
	{
		double area=length*width;
		System.out.println(area);
	}
	
	
	
	
	
	

	public static void main(String[] args) {
		
		Rectangle myObj = new Rectangle();
	    myObj.width =54 ; 
	    myObj.length = 0; 
	  
	}

}
