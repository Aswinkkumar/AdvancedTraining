package com.users;


public abstract class Instrument {
	public abstract void play();
}
