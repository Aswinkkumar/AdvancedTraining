package com.user;

import java.util.Scanner;

public class Numbers {

	
		private static Scanner sc;
		public static void main(String[] args) 
		{
			int number, i;
			sc = new Scanner(System.in);
			
			System.out.print(" Please Enter any Number : ");
			number = sc.nextInt();	
			System.out.println("List of even numbers  from 1 to "+number +":");
			for(i = 1; i <= number; i++)
			{
				if(i % 2 == 0)
				{
					System.out.print(i +"  "); 
				}
			}	
		}
	}