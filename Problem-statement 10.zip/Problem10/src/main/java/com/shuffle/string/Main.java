package com.shuffle.string;

 class Main {
	   
	    public static boolean isInterleaving(String X, String Y, String S)
	    {
	       
	        if (X.length()== 0 && Y.length() == 0 && S.length() == 0) {
	            return true;
	        }
	 
	      
	 
	        if (S.length() == 0) {
	            return false;
	        }
	 
	       
	        if (X.length() != 0 && S.charAt(0) == X.charAt(0)) {
	            return isInterleaving(X.substring(1), Y, S.substring(1));
	        }
	 
	        
	 
	        if (Y.length() != 0 && S.charAt(0) == Y.charAt(0)) {
	            return isInterleaving(X, Y.substring(1), S.substring(1));
	        }
	 
	        return false;
	    }
	 
	    public static void main(String[] args)
	    {
	        String X = "ABC";
	        String Y = "DEF";
	        String S = "DABECF";
	 
	        if (isInterleaving(X, Y, S)) {
	            System.out.print("Interleaving");
	        }
	        else {
	            System.out.print("Given string is not interleaving of X and Y");
	        }
	    }
}