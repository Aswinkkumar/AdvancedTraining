package com.staircase;

import java.util.Scanner;

public class ClimbingStairs {

	
	static int step(int p)
	{
		if (p <= 1)
			return p;
		return step(p - 1) + step(p - 2);
	}


	static int countWays(int n)
	{
		return step(n+ 1);
	}

	
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the total number of steps");
		int steps=sc.nextInt();
		System.out.println("The total number of ways to climb "+steps+" stairs is : "+step(steps));
	}}