package com.rectangle;

public class Main {
	public static void main(String args[]) {
	  Rectangle obj = new Rectangle();
      obj.input();
      obj.calculate();
      obj.display();
  }
}