package com.arraymethod;

import java.util.Arrays;

public class Array {
	public static void main(String[] args) {
		int a[]= {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0};
		int sum=0;
		
		
		 for( int num : a) {
	          sum = sum+num;
	      }
         
         a[15] = sum;
         
         for(int i=0;i<a.length;i++)
         {
         System.out.print(" "+a[i]);
         }
         
         double average = sum / a.length;
         System.out.println("");
         System.out.format("The average is: %.2f", average);
         
         
         {
         int minValue = a[0];
         
         for (int i = 0; i < a.length; i++) {
   
             
   
             if (a[i] < minValue)
   
                 minValue =a[i];
         }
         System.out.println("");
         System.out.println("Smallest element present in given array is: "+ minValue);
         a[16]=minValue;
         
        
         
         
     }
         
	}

}