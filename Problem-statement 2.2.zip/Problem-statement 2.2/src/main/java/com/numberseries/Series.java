package com.numberseries;

import java.util.Scanner;

public class Series {

		  public static void main(String[] args) {

		    int n = 13;
		    		int firstTerm ; 
		    		int secondTerm ;
		    		 Scanner sc = new Scanner(System.in);
		    		   System.out.print("Enter first term ");
		    		   firstTerm =sc.nextInt();
		    		   System.out.print("Enter second term ");
		    		   secondTerm =sc.nextInt();
		    		   
		    System.out.println("Series till " + n + " terms:");

		    for (int i = 1; i <= n; ++i) {
		      System.out.print(firstTerm + ", ");

		      // compute the next term
		      int nextTerm = firstTerm + secondTerm;
		      firstTerm = secondTerm;
		      secondTerm = nextTerm;
		    }
		  }
		}