package com.filehandling;
import java.io.*;
import java.util.*;

public class FileCopy {

		public static void main(String[] args)
			throws IOException
		{

			
			FileInputStream fis = null;
			FileOutputStream fos = null;

			try {

				
				fis = new FileInputStream(
					"D:\\vitamin.txt\\");

			
				fos = new FileOutputStream(
					"D:\\vitamin2.txt\\");

				int c;

				while ((c = fis.read()) != -1) {

					fos.write(c);
				}

				System.out.println(
					"copied the file successfully");
			}
			finally {

				if (fis != null) {

					fis.close();
				}
				if (fos != null) {

					fos.close();
				}
			}
		}
	}


