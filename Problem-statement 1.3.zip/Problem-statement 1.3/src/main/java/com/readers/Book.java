package com.readers;

public class Book
{
    private String book_title;
    private int book_Price;
    private String authorName;
    
    public void setBookName(String bookName)
    {
        this.book_title=bookName;
    }
    
    public String getBookName()
    {
        return this.book_title;
    }
    
    public void setBookPrice(int bookPrice)
    {
        this.book_Price=bookPrice;
    }
    
    public int getBookPrice()
    {
        return this.book_Price;
    }
    
    public void setAuthorName(String authorName)
    {
        this.authorName=authorName;
    }
    
    public String getAuthorName()
    {
        return this.authorName;
    }
}